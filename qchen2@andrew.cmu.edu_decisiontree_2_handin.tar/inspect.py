import csv
import math
import sys

def entropy( num_dem, num_rep):
	prob_dem = num_dem/( num_dem + num_rep)
	prob_rep = num_rep/( num_dem + num_rep)

	return -prob_dem*math.log2(prob_dem) - prob_rep*math.log2(prob_rep)

def helper_error( num_dem, num_rep):
	if num_dem >= num_rep:
		return num_rep/(num_dem + num_rep)
	else:
		return num_dem/(num_dem + num_rep)


if __name__ == '__main__':

	infile  = sys.argv[1]
	outfile = sys.argv[2]

	num_dem, num_rep = 0, 0

	with open(infile,'r') as f1:
		reader = csv.reader(f1, delimiter = '\t')
		for row in reader:
			if row[2] == 'democrat':
				num_dem += 1
			if row[2] == 'republican':
				num_rep += 1

	val_entropy = entropy(num_dem, num_rep)
	val_error   = helper_error(num_dem, num_rep)

	with open(outfile,'w') as f2:
		f2.write("entropy:" + str(val_entropy) +'\n' )
		f2.write("error:" + str(val_error)     )






